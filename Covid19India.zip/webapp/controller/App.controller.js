sap.ui.define([
		"com/sap/dinesh/covid19india/dashboard/controller/BaseController",
		"sap/ui/model/json/JSONModel"
	], function (BaseController, JSONModel) {
		"use strict";

		return BaseController.extend("com.sap.dinesh.covid19india.dashboard.controller.App", {

			onInit : function () {
				
			}
		});

	}
);